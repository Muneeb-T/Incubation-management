let config = require('../config.json'),
  initializeLogger = require('../services/Logger').init;

if (!global.pm) {
  global.pm = {};
}

global.pm.config = {
  get: (key) => config[key]
};

global.pm.logger = console; // Have console logs until the logger is initialized.
initializeLogger(); // Initialize logger and set it to pm.logger
