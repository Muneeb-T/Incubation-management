const { exec } = require('child_process');
const _ = require('lodash');


/**
 * Function responsible to give host architecture on which the application launched on
 * @param {*} cb
 */
function getHostArch (cb) {
  if (_.includes(process.platform, 'win32')) {
    // Case where running 64 bit binary on an 64 bit arch machine
    if (_.includes(process.env.PROCESSOR_ARCHITECTURE, '64')) {
      return cb('x64');
    }

    // Case where running 32 bit binary on an 64 bit arch machine
    if (_.includes(process.env.PROCESSOR_ARCHITECTURE, 'x86') && process.env.PROCESSOR_ARCHITEW6432) {
      return cb('x64');
    }

    // Case where running 32 bit binary on an 32 bit arch machine
    if (_.includes(process.env.PROCESSOR_ARCHITECTURE, 'x86')) {
      return cb('ia32');
    }

    return cb('null');
  }

  if (_.includes(process.platform, 'linux')) {
    let linuxCommand = `arch_name="$(uname -m)"
                if [ "$arch_name" = "x86_64" ]; then
                  echo "x64"
                elif [ "$arch_name" = "i686" ]; then
                  echo "x32"
                else
                  echo "Unknown architecture: $arch_name"
                fi`;
    exec(linuxCommand, (error, stdout, stderr) => {
      if (error) {
        pm.logger.info(`~HostArchitectureService error: ${error}`);
        return cb('null');
      }

      // Case where running 64 bit binary on an 64 bit arch machine
      if (_.includes(stdout, '64')) {
        return cb('x64');
      }

      // Case where running 64 bit binary on an 32 bit arch machine
      if (_.includes(stdout, '32')) {
        return cb('x32');
      }

      return cb('null');
    });
  }

  if (_.includes(process.platform, 'darwin')) {
    let macOsCommand = `arch_name="$(uname -m)"
                if [ "$arch_name" = "x86_64" ]; then
                  if [ "$(sysctl -in sysctl.proc_translated)" = "1" ]; then
                    # Case where running 64 bit binary on an arm64 bit arch machine
                    echo "arm64"
                  else
                    # Case where running 64 bit binary on an 64 bit arch machine
                    echo "x64"
                  fi
                elif [ "$arch_name" = "arm64" ]; then
                  # Case where running arm64 bit binary on an arm64 bit arch machine
                  echo "arm64"
                else
                  echo "$arch_name"
                fi`;

    exec(macOsCommand, (error, stdout, stderr) => {
      if (error) {
        pm.logger.info(`~HostArchitectureService error: ${error}`);
        return cb('null');
      }

      if (_.includes(stdout, 'arm64')) {
        return cb('arm64');
      }

      if (_.includes(stdout, 'x64')) {
        return cb('x64');
      }

      return cb(stdout.trim());
    });
  }
}


module.exports = {
  getHostArch
};
